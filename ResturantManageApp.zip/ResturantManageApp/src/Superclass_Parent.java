
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Superclass_Parent {
    public double FLiet_o_fish;
    public double chikenBurger;
    public double chikenLegend;
    public double chikenBurgerM;
    public double BaconCheeseBurger;
     
    
    public double milkshake;
    public double vanillacone;
    public double classvanilla;
    public double vanmilkshake;
    public double chocmilkshake;
    
      public double Meals;
      public double Drink;
      public double TotalofMd;
      
      
       public double AllTotalofMd;
    
    
    
    public double GetAmount(){
        Meals=FLiet_o_fish + chikenBurger + chikenLegend + chikenBurgerM + BaconCheeseBurger;
        
        Drink=milkshake+ vanillacone+classvanilla+vanmilkshake+chocmilkshake;
        TotalofMd=Meals+Drink;
        AllTotalofMd=  TotalofMd;
        return AllTotalofMd;
    }
    
    private JFrame frame;
    
    public void iExitSystem(){
        frame =new JFrame("Exit");
      if(JOptionPane.showConfirmDialog(frame,"if you want to exit ","Restaurant management system",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION){
      
          System.exit(0);
    }
    }
    
    // =================price===============================
     public double pFLiet_o_fish=3.56;
    public double pchikenBurger=2.95;
    public double pchikenLegend=3.98;
    public double pchikenBurgerM=2.65;
    public double pbaconCheeseBurger=2.64;
     
    
    public double pmilkshake=2.10;
    public double pvanillacone=2.20;
    public double pclassvanilla=2.50;
    public double pvanmilkshake=1.95;
    public double pchocmilkshake=2.37;
    
    
    //+=============================================================
    
    public double mcTax=0.90;
    public Double cFindTax(double cAmount){
        double FindTax=cAmount-(cAmount*mcTax);
        return FindTax;
    }
}
